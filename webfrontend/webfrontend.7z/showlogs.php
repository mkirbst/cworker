<?php
session_start();
if (TRUE == $_SESSION['eingeloggt'])  {
}





?>
