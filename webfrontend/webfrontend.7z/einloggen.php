<?php
    session_start();    //muss bei Verwendung von Sessions immer zuerst stehen !!!!
    
    /*
     * Bereits fehlgeschlagene Loginversuche ? Wenn nicht, Variable initialisieren !
     */
    if( !(isset($_SESSION['failedlogins'])))  {
        $_SESSION['failedlogins'] = 0;
    }


    /*
     * falls vorhanden, hole Kontaktdaten per POST
     */
    if (isset($_POST['passwort'])) { 
        // do something with $_POST['value'] 

        $benutzername   = $_POST["benutzername"];
        $passwort       = $_POST["passwort"];
    
        $ds = ldap_connect("53.100.11.55");
        if ($ds) {
            $bind = ldap_bind($ds, $benutzername, $passwort);
            if ($bind)
            {
                $_SESSION['eingeloggt'] = TRUE;
            } 
            ldap_close($ds);
        }
        
    } else {
        $benutzername   = "";
        $passwort       = "";
    
        $_SESSION['eingeloggt'] = FALSE;
    }
    /*
     * Kontrolliere ob Benutzername/Passwort korrekt eingegeben
     */
    /*
    if("max" == $benutzername && "42" == $passwort)  { //sichere Version, da 123 kein Wert zugewiesen werden kann
        //Neue Variable zum pruefen ob eingeloggt
        $_SESSION['eingeloggt'] = TRUE;
    }
    */ 
    
    
      
    
    
    /*
     * führe entsprechende Aktion aus
     */
    if(!(isset($_SESSION['eingeloggt']))) {
        $_SESSION['eingeloggt'] = FALSE;
    } 
    if(TRUE == $_SESSION['eingeloggt'])  {  //einloggen erfolgreich
        echo date("H:i:s") . "    Hallo ". $benutzername .". Willkommen zur&uuml;ck :o)<br />";
        echo "Deine Session-ID ist:  ". session_id()."<br />";
        if($_SESSION['failedlogins'] > 1)  {
            $_SESSION['failedlogins']--;
            echo "Fehlgeschlagene Loginversuche seit letzter Anmeldung: ". $_SESSION['failedlogins'] ."<br /><br />";
            $_SESSION['failedlogins'] = 0;
        }
        ?>
        <form name="blogout" action="einloggen.php" method="post" enctype="text/html">
            <input type="Submit" name="logout" value="logout" action="<?php session_destroy();?>"/>
        </form>
        <?php
        echo "<br /><br />";
       	//phpinfo(32);
	 echo "<br /><br />";
        

	readfile("visitors.log");
    } else {//einloggen fehlgeschlagen
        $_SESSION['failedlogins'] = $_SESSION['failedlogins'] + 1;

        
        
        if($_SESSION['failedlogins'] > 1)  {
            ?><h2>Zugriff verweigert.</h2><br /><br /><?php
        
            if(($benutzername == "" || $passwort == ""))
            echo "<br><br>Bitte Benutzername und Passwort eingeben!!<br><br>";
        }

        
        
        ////HTML-Formular wieder anzeigen
        echo "
        <form action=\"einloggen.php\" method=\"post\">
            Benutzername:<br />
            <input type=\"text\" name=\"benutzername\" />
            <br />

            Passwort:<br />
            <input type=\"password\" name=\"passwort\"/>
            <br />

            <input type=\"submit\" value=\"einloggen\"/>
        </form>";
    }  

    
    
    
    
?>