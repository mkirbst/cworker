<html>
    <head>
        <title>Dateiindexer</title>
    </head>
    
    <!-- UTF8-Encodierung fuer korrekte Darstellung der Umlaute in Verbindung mit htmlspecialchars-->
    <meta http-equiv="Content-Type"    content="text/html; charset=utf-8" />

    <body>
    <?php
        $DEBUG = true;

        echo "Verbinde zu SQL-Server: ";

        if($db = mysqli_connect("localhost", "dbworker", "Schl8ship", "workerdb"))  {
                //mysqli_select($db, "workerdb");
                echo "Verbindungsaufbau erfolgreich!!";
                $count = 0;

                //alfresco 192.168.40.138
                $sql = "SELECT * FROM  `test` WHERE csum='6be120bd425f8772c4c0db9573da91b72e259f943c1821ef97738d4db3dfa6fdc28b729b69b6b9f733119b41c6f838bcb6fa0bd006ace7024ee4381b58652965';";
                //$sql = "select csum, path from `snapshot_Q:\_20111209154352` group by csum having count(*) > 1 ORDER BY csum;";
                //$sql = "select csum, path from `test` group by csum having count(*) > 1 ORDER BY csum;";
                //$sql = "SELECT MIN(stime) FROM dbworkerino LIMIT 0,30;";
                //$sql = "select * from `snapshot_Q:\_20111209154352` where owner='broderdj';";

                //$sql = "SELECT * FROM  `snapshot_Q:\_20111209154352` WHERE MAX(stime)";
                
                
                //alle benutzer:  owner.php
                //$sql = "SELECT DISTINCT owner FROM `snapshot_Q:\_20111209154352` ORDER BY owner;";
                
                if($ergebnis = mysqli_query($db, $sql)) {
                    echo "<br><h1>".$sql."</h1><br>";
                    echo "<ul>";
                    while ($zeile = mysqli_fetch_assoc($ergebnis)) {
                        //echo "<li>". htmlspecialchars($zeile["csum"]).": ".htmlspecialchars($zeile["path"])."</li>";
                        echo "<li>"."[".htmlspecialchars($zeile["csum"])."]: ". htmlspecialchars($zeile["path"]);


                        $count++;
                    }
                    echo "<ul> ".$count." Treffer.<ul>";

                }





                mysqli_close($db);

        } else {
                echo "Fehler!!!";
        }
    ?>
    </body>
</html>
