<?php

//if(checkNTUser("kirbst", "cNtN.5db6!")) echo "ok";
//else echo "denied";
phpinfo();

function checkNTUser ($username,$passwort) 
 { 
   $ldapserver = '53.100.11.55'; 
   $ds=ldap_connect($ldapserver); 
   if ($ds) 
    { 
      $dn="cn=$username,cn=Users, DC=local, DC=BAMBERG"; 
      $r=@ldap_bind($ds,$dn,$passwort);  
       if ($r) 
        { 
          return true; 
        } 
       else 
        { 
          return false; 
        } 
     } 
 }

/*
// Base DN bezeichnet die oberste OU unter der die User zu finden sind.  
$basedn = "ou=Kirbst,dc=BAMBERG,dc=de"; 
$server = "BAMBERG.Local" ;

// da der Zugriff auch ohne Anmeldung m�glich sein soll, hab ich einen extra User im AD angelegt, um mich mit dem Server zu verbinden. 
$username = "kirbst" ;
$password = "cNtN.5db6!"; 
 
$ldap_port = "389" ;

// LDAP Abfrage  
// ich hab einen erweiterten Filter genommen, da ich nicht nur die User des AD haben wollte, sondern auch Kontakteintr�ge. 
// $filter = "(&(objectClass=user)(objectCategory=person)(cn=*))"; 
//$filter = "(&(|(objectClass=user)(objectClass=contact))(objectCategory=person)(cn=*))"; 

// Verbindung zum AD herstellen 
$connectid = @ldap_connect($server); 

// Ihr k�nnt dies auch nutzen, um z.B. Usernamen und Passwort z.B. f�rs Intranet zu verifizieren. 
$binding = @ldap_bind($connectid,$username,$password) or die("Fehler"); 

// AD auslesen 
$search = @ldap_search($connectid,$basedn,$filter); 
$result = ldap_get_entries($connectid,$sr); 

// in $result sind nun alle User mit allen Informationen enthalten. 
echo $result;
*/
?>
