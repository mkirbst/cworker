<html>
    <?php
        echo "<title>Dateieigentuemer</title>";
    ?>
    <head>
        Dateieigentuemer
    </head>
    
    <!-- UTF8-Encodierung fuer korrekte Darstellung der Umlaute in Verbindung mit htmlspecialchars-->
    <meta http-equiv="Content-Type"    content="text/html; charset=utf-8" />

    <?php
        $DEBUG = true;

        echo "Verbinde zu SQL-Server: ";

        if($db = mysqli_connect("localhost", "dbworker", "Schl8ship", "workerdb"))  {
                //mysqli_select($db, "workerdb");
                echo "Verbindungsaufbau erfolgreich!!";
                $count = 0;
    //alle benutzer:
                $sql = "SELECT DISTINCT owner FROM `snapshot_Q:\_20111209154352` ORDER BY owner;";
                
                if($ergebnis = mysqli_query($db, $sql)) {
                    echo "<br><h1>".$sql."</h1><br>";
                    echo "<ul>";
                    while ($zeile = mysqli_fetch_assoc($ergebnis)) {
                        echo "<li>". htmlspecialchars($zeile["owner"]);
                        $count++;
                    }
                    echo "<ul> ".$count." Treffer.<ul>";
                }
                mysqli_close($db);

        } else {
                echo "Fehler!!!";
        }
    ?>
</html>
