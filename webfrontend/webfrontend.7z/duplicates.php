<html>
    <?php
        echo "<title>Dateiindexer</title>";
    ?>
    <head>
        Duplikate
    </head>
    
    <!-- UTF8-Encodierung fuer korrekte Darstellung der Umlaute in Verbindung mit htmlspecialchars-->
    <meta http-equiv="Content-Type"    content="text/html; charset=utf-8" />

    <?php
        $DEBUG = true;

        echo "Verbinde zu SQL-Server: ";

        if($db = mysqli_connect("localhost", "dbworker", "Schl8ship", "workerdb"))  {
                //mysqli_select($db, "workerdb");
                echo "Verbindungsaufbau erfolgreich!!";
                $count = 0;

                //alfresco 192.168.40.138
                //$sql = "SELECT * FROM  `dbworker` LIMIT 0 , 30;";
                
                //Erstellen der Duplikate:
                //$sql = "select ctime,owner,dom,path,size,csum from `files` group by csum having count(*) > 1 ORDER BY csum;";
                
                //Anzeige aller doppelten Dateien:
                $sql = "SELECT files.ctime, files.csum, files.path, files.size, files.owner, files.dom FROM files, dups WHERE files.csum = dups.csum ORDER BY csum;";
                
                
                //$sql = "select ctime,owner,dom,path,size,csum from `test` ORDER BY csum;";
                

                //$sql = "SELECT MIN(stime) FROM dbworkerino LIMIT 0,30;";
                //$sql = "select * from `snapshot_Q:\_20111209154352` where owner='broderdj';";

                //$sql = "SELECT * FROM  `snapshot_Q:\_20111209154352` WHERE MAX(stime)";
                
                
                //alle benutzer:  owner.php
                //$sql = " SELECT ctime,path,size FROM `snapshot_Q:\_20111209154352` where owner='broderdj' ORDER BY ctime LIMIT 0, 1000;";
                
                if($ergebnis = mysqli_query($db, $sql)) {
                    echo "<br><h1>Auflistung der Duplikate auf Laufwerk Q</h1><br>";
                    echo "<ul>";
                    echo "DEBUG: ".$sql;
                    echo "<li><b>Erstellungsdatum</b> (Domäne\\Eigentümer): Dateipfad<b>[Dateigröße]</b></li>";
                    $lastcsum = "";
                    
                    while ($zeile = mysqli_fetch_assoc($ergebnis)) {
                        //"8918DFG"
                        //echo "<ul><li><b>". htmlspecialchars(date("H:i:s  d.m.Y", $zeile["ctime"]))."</b>(".htmlspecialchars($zeile["dom"])."\\".htmlspecialchars($zeile["owner"])."):".htmlspecialchars($zeile["path"])."<b>[". hrs($zeile["size"]) ."](".$zeile["size"].")</b></li></ul>";
                        if($lastcsum != $zeile["csum"]) {
                            echo $zeile["csum"].":<br>";
                        }
                        echo "<ul><li><b>". htmlspecialchars(date("H:i:s  d.m.Y", $zeile["ctime"]))."</b>(".htmlspecialchars($zeile["dom"])."\\".htmlspecialchars($zeile["owner"])."):".htmlspecialchars($zeile["path"])."<b>[". hrs($zeile["size"]) ."]</b></li></ul>";
                    
                        $lastcsum = $zeile["csum"];
                        $count++;
                    }
                    echo "<ul> ".$count." Treffer.<ul>"; 
                }





                mysqli_close($db);

        } else {
                echo "Fehler!!!";
        }
    
        
        function hrs($size)  {
            $n = 0;
            $nachkomma = 0;
            $erg = "size";
            
            while($size > 1024) {
                $nachkomma = $size % 1024;
                $size /= 1024;
                $n++;
            }
            $erg = $size;
            settype( $erg, 'integer' );
            
            if($nachkomma > 100) {
                $nachkomma /= 100;
                settype( $nachkomma, 'integer' );
                $erg = $erg.",".$nachkomma;
            }
            
            $bytesize = "";
            switch ($n)
            {
                case 1: $bytesize = "KB"; break;  // " KiloByte"; break;
                case 2: $bytesize = "MB"; break;  // " MegaByte"; break;
                case 3: $bytesize = "GB"; break;  // " GigaByte"; break;
                case 4: $bytesize = "TB"; break;  //" TerraByte"; break;
                case 5: $bytesize = "PB"; break;  //" PetaByte"; break;
                case 6: $bytesize = "EB"; break;  //" ExaByte"; break; /*long: file.attrs can be max. 9 exabyte*/
                default: $bytesize ="B "; break;  //" Byte"; break;
            }
        
            return $erg.$bytesize;
        }
        
    ?>
</html>
