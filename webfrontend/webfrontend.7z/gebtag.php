<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<html>
	<HEAD>
	<TITLE>gebtag.php</TITLE>
	</HEAD>    


    <?php echo "Die Internetzeit beträgt:  "; echo time(); ?><br>

    <?php echo 'Die Serverzeit beträgt: '; echo date("H:i:s  d.m.Y"); ?><br>

    <?php   echo "Alter: ";
            echo (time()- mktime(10,30,0,10,10,1983))/(31536000);
            echo " Jahre.";
    ?><br>

    <?php   echo "Das sind ca. ";
            echo (time()- mktime(10,30,0,10,10,1983))/60/60/24;
            echo " Tage.";
    ?><br>

<?php   echo "Noch ";
	if(intval((mktime(0,0,0,10,10,date("Y"))-time())/(60*60*24)) > 0)  {    /*dieses Jahr schon Gebtag gehabt ??*/
		echo intval((mktime(0,0,0,10,10,date("Y"))-time())/(60*60*24));
	} else {
		echo intval((mktime(0,0,0,10,10,date("Y")+1)-time())/(60*60*24));   
	}
	echo " Tage Zeit zum Geschenke kaufen !!<br><br><br><br><br><br><br>";




	if(!file_exists("counter.txt"))  {
		$datei = fopen("counter.txt","w+");
		fclose($datei);
		echo "<br>DEBUG: counterfile angelegt.<br>";
	}

	$datei = fopen("counter.txt","r+");
	$counterstand = fgets($datei, 10);

	if($counterstand == "")  {
		$counterstand = 0;
	}

	$counterstand++;
	
	echo "Besucherzaehler:<br>";
	echo "$counterstand Leute werden Geschenke bringen. :o) <br><br>";

	rewind($datei);
	fwrite($datei, $counterstand);
	fclose($datei);









	if(!file_exists("visitors.log"))  {
		$datei = fopen("visitors.log","w+");
		fclose($datei);
		echo "<br>DEBUG: visitors.log angelegt.<br>";
	}

	$fvisitors = fopen("visitors.log","a+");
	fwrite($fvisitors, date("Y-m-d H:i:s: "));
       fwrite($fvisitors, " gebtag.php: ");
	fwrite($fvisitors, $_SERVER["HTTP_X_FORWARDED_FOR"]);
       fwrite($fvisitors, "  Client-Browser: ".$_SERVER['HTTP_USER_AGENT']."  ");
	fwrite($fvisitors, $_SERVER['REMOTE_HOST']);
       fwrite($fvisitors, "\n");

       fclose($fvisitors);





	
	echo "<br><br><br><br><br><br><br><br><br><br><br><br><br><br>";
	echo "DEBUG:<br>";
	echo "Client-Browser: ".$_SERVER['HTTP_USER_AGENT']."<br>";
	echo "Client-Host:".$_SERVER['REMOTE_HOST']."(".$_SERVER["HTTP_X_FORWARDED_FOR"].")<br>";
	echo "Server-Host:".$_SERVER['SERVER_NAME']."(".$_SERVER['SERVER_ADDR'].")<br>";

	phpinfo(32);
?>
</html>
