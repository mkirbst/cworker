<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
  <head>
    <title>klausur</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  </head>
  <body>
      <FORM name="index" action="regex.php" method="get" enctype="text/html">
        <INPUT TYPE="TEXT" NAME="name" VALUE="" SIZE="20" MAXLENGTH="50"/>
        <INPUT TYPE="SUBMIT" NAME="" VALUE="ABSENDEN" />
      </FORM>
      <?php

      //         IF      08      w       1       -B
      $regex = "^[A-Z]{2}[0-9]{2}[a-z]{1}[0-9]{1}-[A-Z]{1}$";
      $satz = "IF08w1-B";
      
      echo "regex matcht ";
      if(!ereg($regex, $satz)) echo "nicht<br>";
      
      echo "<br>Zahl: ".$_GET['name'] ."  Quersumme: " . qs($_GET['name']) . "<br>";


      function qs($zahl)  {
          if(!isset($zahl)||0==$zahl)  {
              return 0;
          } else {
              //Leerzeichen nach jeder Ziffer einfuegen
              $zahl2 =  chunk_split($zahl, 1, " "); //echo "Zahl2: ".$zahl2."<br>";
              //Zahl an jedem Leerzeichen in Ziffer zerlegen
              $ergarr = explode(" ", $zahl2);

              for($n=0; $n < count($ergarr)-1; $n++)  {
                  //echo "Element: ". $n ." Wert: ".$ergarr[$n]."<br>";
                  $sum = $sum + $ergarr[$n];
              }
              return $sum;
            }
      }


      ////////////////////////////////////////////////////////////////////////
      echo"<br><br><br><br>";
      //Array mit vorgegebenen Werten anlegen und ausgeben
      $arr3 = array(1, -1, 2, -2, 3, -3, 4, -4 , 5, -5);
      for($n=0; $n < count($arr3); $n++) echo "Element: ".$n." Wert: ".$arr3[$n]."<br>";

      //aus negativen Werten neues Array generieren
      for($n=0; $n < count($arr3); $n++)  {
          if(0 > $arr3[$n]) $arr3neg[] = $arr3[$n];
      }
      echo"<br><br>";

      //Array mit negativen Werten ausgeben
      for($n=0; $n < count($arr3neg); $n++) echo "Element: ".$n." Wert: ".$arr3neg[$n]."<br>";





      ////////////////////////////////////////////////////////////////////////
      echo"<br><br><br><br>";
      //Zufallsarray erzeugen
      for($n=0; $n<50; $n++)  {
          $werte[$n] = rand(0,10);
      }

      //Zufallsarray ausgeben,
      //sowie jeweiligen Wert als Index fuer neues Array verwenden und zaehlen
      for($n = 0; $n < count($werte); $n++) {
          echo $werte[$n]."  ";
          $anzwerte[$werte[$n]]++;
      }

      //Zaehlarray ausgeben
      echo "<br/><br/>";
      for($n = 0; $n < count($anzwerte); $n++) {
          echo "Wert:  " .$n. "   Anzahl: ". $anzwerte[$n]."<br/>";
      }



//       echo var_dump($arr);

        echo $_GET['name']."<br>";
        echo $_SERVER["QUERY_STRING"]."<br>";
        echo $_SERVER["REQUEST_METHOD"]."<br>";
        
        if(!isset($_GET['name'])) echo "name noch nicht gesetzt";

        phpinfo(32);
      ?>
  </body>
</html>
