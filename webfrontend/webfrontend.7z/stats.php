<html>
    <?php
        echo "<title>Dateiindexer</title>";
    ?>
    <head>
        Duplikate
    </head>
    
    <!-- UTF8-Encodierung fuer korrekte Darstellung der Umlaute in Verbindung mit htmlspecialchars-->
    <meta http-equiv="Content-Type"    content="text/html; charset=utf-8" />

    <?php
        $DEBUG = true;

        echo "Verbinde zu SQL-Server: ";

        
        $link = mysql_connect("localhost", "dbworker", "Schl8ship");
        mysql_select_db("workerdb", $link);
        
        $result = mysql_query("SELECT * FROM files", $link); 
        $num_rows = mysql_num_rows($result); 
        echo "Anzahl det Dateien auf Laufwerk Q: $num_rows\n";
        
        $result = mysql_query("SELECT * FROM dups", $link); 
        $num_rows = mysql_num_rows($result); 
        echo "Anzahl det Duplikate auf Laufwerk Q: $num_rows\n";
        
        //laufzeit sqlabfrage
        $result = mysql_query("SELECT MIN(stime) FROM files;", $link); 
        $stime_min = mysql_num_rows($result); 
        $result = mysql_query("SELECT MAX(stime) FROM files;", $link); 
        $num_rows = mysql_num_rows($result); 
        echo "Anzahl det Duplikate auf Laufwerk Q: $num_rows\n";
        
        
        
        
        mysql_close($link);
        
        
        function hrs($size)  {
            $n = 0;
            $nachkomma = 0;
            $erg = "size";
            
            while($size > 1024) {
                $nachkomma = $size % 1024;
                $size /= 1024;
                $n++;
            }
            $erg = $size;
            settype( $erg, 'integer' );
            
            if($nachkomma > 100) {
                $nachkomma /= 100;
                settype( $nachkomma, 'integer' );
                $erg = $erg.",".$nachkomma;
            }
            
            $bytesize = "";
            switch ($n)
            {
                case 1: $bytesize = "KB"; break;  // " KiloByte"; break;
                case 2: $bytesize = "MB"; break;  // " MegaByte"; break;
                case 3: $bytesize = "GB"; break;  // " GigaByte"; break;
                case 4: $bytesize = "TB"; break;  //" TerraByte"; break;
                case 5: $bytesize = "PB"; break;  //" PetaByte"; break;
                case 6: $bytesize = "EB"; break;  //" ExaByte"; break; /*long: file.attrs can be max. 9 exabyte*/
                default: $bytesize ="B "; break;  //" Byte"; break;
            }
        
            return $erg.$bytesize;
        }
        
    ?>
</html>
