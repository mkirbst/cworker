<?php

$erle= <<<ERL

Der Datenuebertragungs-Erlenkoenig
Wer routet so spaet durch Nacht und Wind?
Es ist der Router, er routet geschwind.
Bald routet er hier, bald routet er dort.
Jedoch die Pakete sie kommen nicht fort!
Sie sammeln und draengeln sich, warten recht lange
in einer zu niedrig priorisierten Schlange.
Die Schlangen sind voll, der Router im Stress,
da meldet sich vorlaut der Routingprozess:
"All Ihr Paeckchen Ihr sorgt Euch zu viel,
nicht der IP-Host, nein, der Weg ist das Ziel.
Es komme gar bald einem jeden zu Gute
eine sorgsam geplante und loopfreie Route.
Des Netzes verschlungene Topologie
entwirr ich mit Dijkstra's Zeremonie.
Der Lohn: Eine herrliche Routingtabelle,
dort stehn sogar Routen zu Himmel und Hoelle.
Vergiftet der Rueckweg, das Blickfeld gespalten,
mit RIP wird die Welt nur zum Narren gehalten.
Doch OSPF durchsucht schnell und bequem
mein ganz und gar autonomes System.
Fuer kunstvolle Routen, das vergesst bitte nie,
benoetigt man Kenntnis der Topologie.
Zu Ueberraschungs- und Managementzwecken
durchsuch ich mit RMON die hintersten Ecken.
Kein Winkel des Netzes bleibt vor mir verborgen
mit SNMP kann ich alles besorgen.
Wohlan nun Ihr Paeckchen die Reise beginnt.
Mit jeder Station Eure Lebenszeit rinnt.
Doch halt Ihr Paeckchen bevor ich's vergesse:
Besorgt euch mit NAT eine neue Adresse."
"Mein Router, mein Router was wird mir so bang.
Der Weg durch das WAN ist gefaehrlich und lang."
"Mein Paeckchen, mein Paeckchen so fuerchte Dich nicht,
denn ueber Dich wacht eine Sicherungsschicht."
"Mein Router, mein Router was wird mir so flau.
Dort draussen am LAN-Port da wartet die MAU."
"Mein Paeckchen, mein Paeckchen Dir droht nicht der Tod,
denn ueber Dich wacht ja der Manchester-Code.
Doch halte dich fern von der flammenden Mauer.
Die sorgt selbst bei mir noch fuer aengstliche Schauer."
"Mein Router, mein Router wie glaenzt dort voll Tuecke
der schmale und schluepfrige Weg auf der Bruecke."
"Oh weh! Das Netz ist mit Broadcasts geflutet.
Ach haett ich doch niemals zur Bruecke geroutet!"
"Mein Paeckchen - Kopf hoch. Du musst nicht verzagen,
an Dich wird sich niemals ein Bitfehler wagen."
Schnell wie der Wind geht die Reise nun weiter,
durch helle und funkelnde Lichtwellenleiter.
"Mein Paeckchen, mein PaPREG_OFFSET_CAPTURE
eckchen willst Du mit mir gehen:
Die Wunder des Frame-Relay-Netzes ansehen!"
"Mein Router, mein Router ja hoerst Du denn nicht,
was die WAN-Wolke lockend mir leise verspricht."
"Glaub mir mein Paeckchen im LAN da entgeht
Dir sowieso Lebens- und Dienstqualitaet.
Reise nur weiter ganz ruhig und sacht.
Quer durchs ATM-Netz mit FRF8."
"Mein Router, mein Router man hat mich verfuehrt,
zerlegt, verschaltet und rekombiniert."
"Mein Paeckchen das macht nichts. Nun sparen wir viel,
ein VPN-Tunnel der bringt Dich sicher ans Ziel.
DiffSERV und TOS-Feld merk Dir die Worte,
die oeffnen zu jedem Router die Pforte."
Finster der Tunnel, die Bandbreite knapp,
wie schoen war die Backplane im eigenen Hub.
Am Ende des Tunnels: Das Paeckchen ist weg,
vernichtet vom Cyclic Redundancy Check.
ERL;


$erg = array();
preg_match_all("/\b\w{1,}/",$erle,$erg);

$anzahl = array_count_values($erg[0]);

asort($anzahl);

foreach($anzahl as $word => $count)  {
	echo $word. " = ".$count. "<br>"; 
}

?>
