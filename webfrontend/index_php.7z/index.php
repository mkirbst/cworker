﻿<html>
    <?php
        echo "<title>Dateiindexer</title>";
    ?>
    <head>
        Duplikate
    </head>
    
    <!-- UTF8-Encodierung fuer korrekte Darstellung der Umlaute in Verbindung mit htmlspecialchars-->
    <meta http-equiv="Content-Type"    content="text/html; charset=utf-8" />

    <?php
        $DEBUG = true;

        echo "Verbinde zu SQL-Server: ";

        if($db = mysqli_connect("localhost", "dbworker", "", "workerdb"))  {
                //mysqli_select($db, "workerdb");
                echo "Verbindungsaufbau erfolgreich!!";
                $count = 0;

                //alfresco 192.168.40.138
                $sql = "SELECT * FROM  `dbworker` LIMIT 0 , 30;";
                //$sql = "select csum, path from dbworker group by csum having count(*) > 1 ORDER BY csum;";
                //$sql = "SELECT MIN(stime) FROM dbworkerino LIMIT 0,30;";
                //$sql = "SELECT * FROM  dbworkerino WHERE = \"ochs\"; ";

                if($ergebnis = mysqli_query($db, $sql)) {
                    echo "<br><h1>Duplikate</h1><br>";
                    echo "<ul>";
                    while ($zeile = mysqli_fetch_assoc($ergebnis)) {
                        echo "<li>". htmlspecialchars($zeile["csum"]).": ".htmlspecialchars($zeile["path"])."</li>";


                        $count++;
                    }
                    echo "<ul> ".$count." Duplikate.<ul>";

                }





                mysqli_close($db);

        } else {
                echo "Fehler!!!";
        }
    ?>
</html>
